<?php

$cfg = array(
    'max_timeout' => 1200
);